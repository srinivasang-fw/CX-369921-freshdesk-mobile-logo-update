---
name: cxbu-android
disable-model-invocation: false
description: >-
  cxbu-android: wires the sibling cxbu-android repo into this Freshdesk app
  (Gradle composite-style): settings.gradle include/projectDir plus matching
  implementation project(...) vs com.freshworks.cxbu.mobile Maven. Use for
  local CXBU work, per-module toggles, or Maven vs project resolution.
---

# CXBU Android

## Local checkout

- **Relative to this repo root:** `../cxbu-android` (see `settings.gradle` `projectDir` paths).
- **Pattern:** `project(':name').projectDir = new File(settingsDir, '../cxbu-android/<folder>')`  
  Folder names match the table below unless the user’s clone differs.

## Module catalog (prompt → Gradle)

Interpret the user’s prompt and map to **Gradle project** names (leading `:`):

| Say this in a prompt | Gradle project | Maven artifact name | Folder under cxbu-android |
|----------------------|----------------|---------------------|---------------------------|
| ui, UI, cxbu ui | `:ui` | `ui` | `ui` |
| editor | `:editor` | `editor` | `editor` |
| tools | `:tools` | `tools` | `tools` |
| notifications | `:notifications` | `notifications` | `notifications` |
| migration | `:migration` | `migration` | `migration` |
| compose, compose UI, composeUi | `:composeUi` | `composeUi` | `composeUi` |

If the user lists multiple modules (“ui and tools only”), enable **each** of those.  
If they say “all local” or “full composite”, enable **all** rows.

## Selective local wiring (follow in order)

Do **not** assume every module is local. Apply only what the prompt asks for.

### 1. `settings.gradle`

For **each** CXBU module:

- **Local (user asked for this module):** use an active pair:

```gradle
include ':ui'
project(':ui').projectDir = new File(settingsDir, '../cxbu-android/ui')
```

- **Not local:** wrap that module’s `include` + `projectDir` in a block comment `/* ... */`  
  (same style as the original template), or remove those two lines if the file uses only comments for disabled modules.

Keep one short comment at the top of the CXBU block explaining that only some modules may be uncommented.

### 2. Consumer `build.gradle` files (must stay in sync)

Every `implementation` for CXBU must match `settings.gradle`:

- Module **included** in settings → `implementation project(':moduleName')`  
  Example: `implementation project(':ui')` for `:ui`.

- Module **not** included → Maven line:

`implementation "com.freshworks.cxbu.mobile:<artifact>:${cxbuVersion}"`  
(use `<artifact>` from the table: `ui`, `tools`, `composeUi`, …).

**Files that declare CXBU deps** (search if new modules appear):

- `freshdesk_app/build.gradle`
- `freshdesk_backend/build.gradle`
- `threads/build.gradle`
- `fd_attachment/build.gradle`
- `errorhandling/build.gradle`

Edit **every** CXBU line in those files when toggling a module so the build does not reference `project(':x')` for an `x` that was commented out of `settings.gradle`.

### 3. Transitive / build failures

If Gradle fails because a local module expects another CXBU project, suggest adding that sibling module to the **local** set in the same way (update `settings.gradle` + all consumer lines).

## Reading source (any prompt)

To inspect CXBU behavior, read or grep under  
`<this-repo-root>/../cxbu-android/<folder>/` even when that module is still on Maven in Gradle.

## Defaults when the prompt is vague

- Prefer asking: “Which CXBU modules should be local (ui, tools, editor, notifications, migration, composeUi)?”
- If they say “use local cxbu” with no list, enable **all** modules from the catalog and use `project(...)` everywhere those artifacts appear.

## Agent checklist

1. Parse requested module names from the user message.
2. Patch `settings.gradle`: comment or uncomment each module’s `include` + `projectDir` block.
3. Patch each consumer `build.gradle`: `project(':…')` only for included modules; Maven for the rest.
4. Grep `com.freshworks.cxbu.mobile` and `project(':ui')` etc. to ensure none are inconsistent.
