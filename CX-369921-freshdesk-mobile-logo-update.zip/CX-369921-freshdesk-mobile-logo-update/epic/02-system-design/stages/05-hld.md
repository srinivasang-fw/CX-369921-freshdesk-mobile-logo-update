# HLD — redirected (quick-design)

This epic uses workflow variant **`quick-design`**. Full HLD (Stage 05) is **not** produced as a separate artifact.

**Design of record:**

- [`04c-solution-approach.md`](04c-solution-approach.md) — per-flow and cross-cutting decisions  
- [`system-design-decisions.md`](../system-design-decisions.md) — ADR-001…006  

Stage 06 (LLD) implements the locked decisions above for **Android** first; **iOS** follows when `fd_ios` is available.
