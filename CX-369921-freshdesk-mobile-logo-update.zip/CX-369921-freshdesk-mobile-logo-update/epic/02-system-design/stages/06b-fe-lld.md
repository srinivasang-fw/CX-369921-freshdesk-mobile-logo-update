# LLD — Frontend (Android Native) · CX-369921 Update Mobile Logos

**Epic:** CX-369921  
**Parent design record:** `04c-solution-approach.md`, `system-design-decisions.md` (ADR-001…006)  
**Repo:** `mobile_app_android_fd`  
**Module:** `freshdesk_app`  
**Local path:** `/Users/sgovindarajan/Documents/freshdesk-mobile-repos/mobile_app_android_fd` (branch `main`)  
**Version:** 1.0  
**Date:** 2026-10-07  
**Status:** Draft — ready for implement after Design export sign-off  
**Platform:** Android native (Kotlin/Java, XML resources) — **not** Ember/MFE (cx-fe-lld web rules N/A)

---

## Sources & Grounding

| Input | Source | Status |
|-------|--------|--------|
| Design record | `05-hld.md` (redirect) + `04c-solution-approach.md` | Consulted |
| PRD | `01-prd/prd.md` — US-001, FR-01–FR-06, FR-08 | Consulted |
| Scope & flows | `03-scope-and-flows.md` — F1, F2, F5 (Android); F3/F4 iOS deferred | Consulted |
| ADRs | ADR-001…006 | Consulted — implement exactly |
| Context priming | `04b-context-priming.md` | Consulted — file paths verified locally |
| Local clone | `freshdesk_app/` on `main` | **Primary grounding** — full layout/drawable reads |
| Git MCP / Prism | Not used | User constraint: local-only; noted for checker HIL if required |
| Figma | N/A | Assets from `01-prd/assets/` + Design export grid |

---

## 1. Scope & Dependency on HLD

### 1.1 In scope (Android)

| ID | Requirement | LLD section |
|----|-------------|-------------|
| FR-01 | Splash / loading **full logo** | §9.1, §9.2 |
| FR-02 | In-app menu **logomark only** | §9.3 (More/Account toolbar — ADR-002) |
| FR-03 | Notification **logomark** | §9.4 |
| FR-04 | Launcher **logomark** | §9.5 |
| FR-06 | Manual smoke gate | §9.9 |
| FR-08 | Design sign-off before merge | §16 |

Login and About use **full logo** via shared `ic_full_logo` (ADR-001, ADR-005) — in scope as asset updates, not separate UX.

### 1.2 Out of scope (this LLD revision)

- iOS (`fd_ios`) — duplicate this LLD structure when repo is checked out.
- `splash.json` / `splash_loader.json` Lottie re-author (ADR-004) unless QA flags legacy mark.
- Backend, APIs, feature flags, Jira updates (FR-07).
- `production` / `staging` **flavor** code changes — branding in `src/main/res` only (verified: flavor trees have no logo duplicates).

### 1.3 Traceability

| Source | Description | LLD | Status |
|--------|-------------|-----|--------|
| F1 | Android cold start full logo | §9.1 | Covered |
| F2 | Menu + notification logomark | §9.3, §9.4 | Covered |
| F5 | Pre-release verification | §9.9 | Covered |
| ADR-001 | Central `ic_full_logo` | §9.1 | Covered |
| ADR-002 | More toolbar logomark | §9.3 | Covered |
| ADR-003 | Single logomark source → densities | §9.4, §9.5 | Covered |
| ADR-004 | Lottie deferred | §1.2 | Covered |
| ADR-005 | About keeps full logo | §9.1 | Covered |
| ADR-006 | Manual smoke | §9.9 | Covered |
| US-001 AC | All four Android scenarios | §9.1–§9.5, §9.9 | Covered |

---

## 2. Plan & Feature Gating

No launch party or remote config. Branding applies to all users on standard Freshdesk agent builds (`production` + `staging` flavors share `main` resources).

**Pre-merge gate:** Design sign-off on exported assets (FR-08, PRD §15 Q1).

---

## 3. Data Model & Schema

N/A — drawable/mipmap resources only.

---

## 4. API Contract

N/A.

---

## 5. Services & Business Logic

No Kotlin/Java logic changes **required**. Optional: none unless tint/contrast fixes need programmatic `ImageView` setup (default: XML-only).

**Existing references (do not change IDs):**

| Consumer | Reference |
|----------|-----------|
| Splash | `activity_splash.xml` → `@drawable/ic_full_logo` |
| Login | `activity_login_domain.xml`, `activity_login_credentials.xml` → `@drawable/ic_full_logo` |
| About | `activity_about.xml` → `@drawable/ic_full_logo` |
| Push / tray | `NotificationUtil.kt` → `R.drawable.ic_notification` |
| Migration notification | `MigratorImpl.kt` → `R.drawable.ic_notification` |
| Location foreground service | `LocationService.kt` → `R.mipmap.ic_launcher` (align visually with logomark set) |

---

## 6. Migrations & Data

N/A.

---

## 7. Security, Permissions & Compliance

Static replacement only — no new permissions, network calls, or PII (PRD §8.2). Notification icon must remain a **white silhouette** on transparent background per Android status-bar guidelines (validate on device).

---

## 8. Dependencies

| Dependency | Type | Notes |
|------------|------|-------|
| Brand SVG + density grid | Hard blocker | PRD §15 Q1 — before PR merge |
| Design sign-off | Hard | FR-08 on final PNG/vector exports |
| Android Studio / Gradle | Tooling | Build `freshdesk_app` variant e.g. `playstoreProductionDebug` per team convention |

---

## 9. User Interface (Android resources)

**Owning surface:** Native Android — repo `mobile_app_android_fd`, module `freshdesk_app`, path prefix `freshdesk_app/src/main/`.

### 9.1 Full logo (splash, login, about) — ADR-001, ADR-005

**Source asset:** `01-prd/assets/freshdesk-logo-full-default.png` (738×128) → convert to vector or nodpi raster per Design.

| Action | Path |
|--------|------|
| **Replace / regenerate** | `res/drawable/ic_full_logo.xml` |
| **Verify bindings (no path change expected)** | `res/layout/activity_splash.xml` |
| | `res/layout/activity_login_domain.xml` |
| | `res/layout/activity_login_credentials.xml` |
| | `res/layout/activity_about.xml` |
| **a11y** | Existing `@string/freshdesk_logo` on login/about; ensure splash `ImageView` has `contentDescription` if missing |

**Entry activity:** `java/.../ui/SplashActivity.kt` — no change unless adding contentDescription in XML only.

### 9.2 Logomark drawable (new) — ADR-003

| Action | Path |
|--------|------|
| **Add** | `res/drawable/ic_logomark.xml` (preferred) and/or `drawable-nodpi/ic_logomark.png` |
| **Add string (recommended)** | `res/values/strings.xml` → `freshdesk_logomark` for contentDescription |
| **Source** | `01-prd/assets/freshdesk-logomark-color-default.png` (128×128) + Design grid |

### 9.3 In-app menu — More / Account toolbar — ADR-002

**Surface:** Bottom nav **More** tab → `MoreOptionFragment` → `fragment_more_options.xml` toolbar (PRD “in-app menu”).

**Layout change:** In the toolbar `LinearLayout` (same row as back arrow + `@string/title_account`), add a **logomark-only** `ImageView`:

- `android:id="@+id/brand_logomark"`
- `app:srcCompat="@drawable/ic_logomark"`
- `android:contentDescription="@string/freshdesk_logomark"` (or reuse `freshdesk_logo` if PM prefers single label)
- Size: `@dimen` e.g. 24–32dp height, `wrap_content` width, `scaleType="fitCenter"`
- Placement: **end** of toolbar (`RelativeLayout` → add aligned to parent end, or reorder horizontal chain so mark appears on trailing edge per design mock)

**Do not** replace `@drawable/ic_hamburger_icon` on ticket list — that is navigation chrome, not brand menu ( `fragment_ticket_list.xml` unchanged).

### 9.4 Notification small icon — ADR-003

Replace monochrome-friendly logomark exports at all densities:

| Action | Path |
|--------|------|
| Replace PNGs | `res/drawable-mdpi/ic_notification.png` |
| | `res/drawable-hdpi/ic_notification.png` |
| | `res/drawable-xhdpi/ic_notification.png` |
| | `res/drawable-xxhdpi/ic_notification.png` |
| | `res/drawable-xxxhdpi/ic_notification.png` |

Validate on device: status bar + shade (US-001 Scenario 3). `NotificationUtil.kt` unchanged if drawable name preserved.

### 9.5 Launcher / adaptive icon — ADR-003

| Action | Path |
|--------|------|
| Replace | `res/mipmap-mdpi/ic_launcher.png` |
| | `res/mipmap-hdpi/ic_launcher.png` |
| | `res/mipmap-xhdpi/ic_launcher.png` |
| | `res/mipmap-xxhdpi/ic_launcher.png` |
| | `res/mipmap-xxxhdpi/ic_launcher.png` |
| Update foreground vector | `res/drawable/ic_launcher_foreground.xml` |
| Verify adaptive wrapper | `res/mipmap-anydpi-v26/ic_launcher.xml` |
| Background color | `res/values/ic_launcher_background.xml` (only if Design changes brand plate) |

### 9.6 Theming / dark mode

PRD: single default light-brand assets. Verify contrast on `?colorSurface` / splash white background in smoke; dark-variant follow-up out of scope.

### 9.7 Implementation sequence

1. Obtain signed-off exports (blocker).
2. Update `ic_full_logo` → build → smoke cold start + login.
3. Add `ic_logomark` + toolbar `ImageView` → smoke More tab.
4. Replace `ic_notification` set → smoke push (or test notification).
5. Replace launcher/adaptive set → smoke home screen icon.
6. Complete FR-06 checklist; attach evidence in dev phase.

### 9.8 Component reuse

| Asset | Strategy |
|-------|----------|
| Full logo | **Extend** existing `ic_full_logo` resource ID |
| Logomark | **New** `ic_logomark` — do not reuse `ic_full_logo` on menu |
| Notification | **Replace** existing `ic_notification` files in place |
| Launcher | **Replace** mipmaps + foreground in place |

### 9.9 Testing & quality (manual)

| # | Scenario | Steps | Pass criteria |
|---|----------|-------|---------------|
| T1 | Cold start | Force-stop app → launch | Full logo on splash; no crash |
| T2 | Menu | Open More / Account | Logomark only, no wordmark |
| T3 | Notification | Trigger test push | Status bar icon = logomark |
| T4 | Launcher | Install/update APK | Home screen icon = logomark |
| T5 | Login | Log out → login screens | Full logo still correct |
| T6 | Regression | Quick ticket open + push receive | No functional regression |

No new automated tests required for this epic unless team mandates screenshot tests.

---

## 10. iOS (placeholder)

When `fd_ios` is available, mirror sections 9.1–9.9 with LaunchScreen, AppIcon asset catalog, notification asset set, and identified menu view controller — decisions locked in 04c for iOS to follow Android semantics.

---

## 11. Per-PR checklist (implementer)

- [ ] All files above updated from Design-signed export pack  
- [ ] No accidental edit to `ic_full_logo` usage on About (full lockup OK)  
- [ ] `fragment_more_options.xml` includes logomark per §9.3  
- [ ] Manual smoke T1–T6 documented  
- [ ] No changes outside `mobile_app_android_fd` for this story  

---

## 16. Open Questions

| # | Item | Owner | Notes |
|---|------|-------|-------|
| 1 | Brand SVG + full mipmap/notification grid | Design | PRD §15 Q1 — blocks merge |
| 2 | Exact toolbar placement of logomark (start vs end) | Design / PM | Implement per signed mock when available |
| 3 | Lottie assets show old mark? | QA | ADR-004 follow-up if yes |
| 4 | iOS LLD | Mobile iOS | After repo checkout |
