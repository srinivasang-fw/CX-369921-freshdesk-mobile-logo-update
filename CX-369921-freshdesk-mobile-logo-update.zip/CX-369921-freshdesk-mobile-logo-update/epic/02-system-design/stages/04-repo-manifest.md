# Repo Manifest: Freshdesk mobile logo update

**Epic:** CX-369921  
**Stage:** 04 — Repo discovery  
**Confirmed by:** sgovindarajan_fwinc / srinivasan.govindarajan@freshworks.com (local paths via `git remote -v`)  
**Date:** 2026-10-07

## Discovery Method
**Manual** — PRD + epic `repos.yaml`, local clone verification only. Prism and GitHub MCP were **not** used (per user: no Jira/GitHub changes; local workspace only).

## Repositories
| # | Repo | Type (BE/FE/Full-stack) | Owning Team | Local Path | Status |
|---|------|-------------------------|-------------|------------|--------|
| 1 | `mobile_app_android_fd` | FE (mobile Android) | Freshdesk Mobile (Android) | `/Users/sgovindarajan/Documents/freshdesk-mobile-repos/mobile_app_android_fd` — branch `main` (verified `origin` → `git@github.com:freshdesk/mobile_app_android_fd.git`) | **available** |
| 2 | `fd_ios` | FE (mobile iOS) | Freshdesk Mobile (iOS) | `/Users/sgovindarajan/Documents/freshdesk-mobile-repos/fd_ios` — **no checkout** (directory contains only `.git`; `HEAD` unresolved) | **deferred** — Android-first; populate working tree before iOS LLD |

## Preliminary asset touchpoints (Android — local scan)

| PRD slot | Resource / code (to confirm in 04b) |
|----------|-------------------------------------|
| Load / splash (full logo) | `freshdesk_app/src/main/res/layout/activity_splash.xml` → `@drawable/ic_full_logo`; vector `drawable/ic_full_logo.xml` |
| Login (full logo — same asset) | `activity_login_domain.xml`, `activity_login_credentials.xml` → `@drawable/ic_full_logo` |
| Notification (logomark) | `NotificationUtil.kt` → `R.drawable.ic_notification`; PNGs under `res/drawable-*dpi/ic_notification.png` |
| Launcher (logomark) | `mipmap-*/ic_launcher.png`, `mipmap-anydpi-v26/ic_launcher.xml`, `drawable/ic_launcher_foreground.xml`, `values/ic_launcher_background.xml` |
| In-app menu (logomark) | **TBD in 04b** — no separate logomark drawable found yet; may require new `ic_logomark` + layout/Compose wiring |

**Android flavors (Q17):** `productFlavors` `production` / `staging` on dimension `server` — shared `main` res; flavor-specific dirs `src/playstoreProduction`, `src/playstoreStaging` (verify no duplicate branding under flavor overlays).

## Preliminary asset touchpoints (iOS)

Blocked until `fd_ios` working tree is checked out locally (LaunchScreen, AppIcon, notification assets, menu — per PRD US-002).

## Skipped Repos
None — both repos are in scope. `fd_ios` is not skipped; local tree must be populated before code-grounded stages.

## Cross-Team Sign-offs
- [ ] Brand / Design — density exports + sign-off (see checklist)
- [ ] Freshdesk Mobile (Android) — confirm menu logomark placement vs splash full logo
- [ ] Freshdesk Mobile (iOS) — confirm schemes/targets once repo checkout is available

## Notes
- No remote git operations performed from AIPDLC in this stage (no fetch, push, or PRs).
- Epic intake paths match `repos.yaml` at epic root; workspace-root `repos.yaml` unchanged.
