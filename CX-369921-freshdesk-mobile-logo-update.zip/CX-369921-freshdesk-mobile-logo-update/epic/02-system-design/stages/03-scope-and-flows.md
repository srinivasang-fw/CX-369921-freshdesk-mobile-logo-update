# Scope & Flow Definition: Freshdesk mobile logo update

**Epic:** CX-369921  
**Approved by:** sgovindarajan_fwinc / srinivasan.govindarajan@freshworks.com  
**Approved at:** 2026-10-07

## Feature/Module Inventory
| # | Feature | Status | System/Service | Priority |
|---|---------|--------|----------------|----------|
| F1 | Android splash / loading (full logo) | Modified | `mobile_app_android_fd` | P0 |
| F2 | Android in-app menu logomark | Modified | `mobile_app_android_fd` | P0 |
| F3 | Android notification small icon (logomark) | Modified | `mobile_app_android_fd` | P0 |
| F4 | Android launcher / adaptive icon (logomark) | Modified | `mobile_app_android_fd` | P0 |
| F5 | iOS launch / cold-start branding (full logo) | Modified | `fd_ios` | P0 |
| F6 | iOS in-app menu logomark | Modified | `fd_ios` | P0 |
| F7 | iOS push notification branding (logomark) | Modified | `fd_ios` | P0 |
| F8 | iOS App Icon set (logomark) | Modified | `fd_ios` | P0 |
| F9 | Density / mipmap / icon-set generation from brand PNGs | New (process) | Both repos + epic assets | P0 |

## Testable Flows

### F1: Android — cold start shows full logo
- **Actor**: Support agent (Android)
- **Steps**:
  1. Agent installs or updates build with new assets → taps app icon (logomark on launcher).
  2. App cold-starts → loading/splash shows **full logo** (mark + wordmark).
  3. App reaches main UI without crash; branding matches PRD placement rules.
- **Features involved**: F1, F4, F9

### F2: Android — menu and notification use logomark only
- **Actor**: Support agent (Android)
- **Steps**:
  1. Agent opens in-app menu → **logomark only** (no full lockup).
  2. Agent receives push → status bar/shade shows **logomark** notification icon.
  3. Notification delivery and payload behavior unchanged (visual only).
- **Features involved**: F2, F3

### F3: iOS — cold start shows full logo
- **Actor**: Support agent (iOS)
- **Steps**:
  1. Agent force-quits app (not resume from app switcher) → cold-starts.
  2. Launch/loading experience shows **full logo**.
  3. App reaches main UI without hang on blank launch screen.
- **Features involved**: F5, F8, F9

### F4: iOS — menu, notification, home screen logomark
- **Actor**: Support agent (iOS)
- **Steps**:
  1. Agent opens menu → **logomark only**.
  2. Push appears → branding uses logomark (not full wordmark).
  3. Home screen **App Icon** shows updated logomark (note possible iOS icon cache after upgrade).
- **Features involved**: F6, F7, F8

### F5: Pre-release verification (both platforms)
- **Actor**: Mobile engineer / QA
- **Steps**:
  1. Clone repos per `repos.yaml` → replace assets per repo conventions.
  2. Build Android (emulator/device) and iOS (simulator/device).
  3. Run manual smoke: cold start, menu, notification icon, launcher × both platforms; record results for dev phase (FR-06).
- **Features involved**: F1–F9

## Scope Boundary

### In Scope
- FR-01–FR-05 in **`mobile_app_android_fd`** and **`fd_ios`** only.
- Asset sources: `01-prd/assets/freshdesk-logo-full-default.png`, `freshdesk-logomark-color-default.png` (plus design-approved density exports).
- Local clone, build, manual smoke before store push (FR-06).
- Target **before 15 Oct 2026** with DoD: store submitted/live or PM-documented exception (PRD §3).

### Out of Scope
- Web agent UI, Omni, email/helpkit, product-wide logo sweeps — PRD §3.
- Play/App Store **marketing** screenshots and feature graphics — deferred.
- Jira epic CX-369921 edits from AIPDLC — PRD FR-07.
- Dark-mode / alternate logo variants — single default treatment.
- Functional changes (tickets, Freddy, APIs, permissions).

### Assumed to Exist
- Standard Freshdesk mobile release process and mobile lead ownership of target branch — mobile leads.
- Push notification pipelines (APNs / FCM) unchanged — platform teams.
- No white-label / custom tenant branding on Freshdesk mobile — product assumption.

**Epic classification:** Mobile client / frontend-only (static assets and resource bundles; no backend or API work).

## Dependencies

### Code Dependencies
| # | Dependency | Type (Modified/Consumed) | Hard/Soft | Notes |
|---|-----------|--------------------------|-----------|-------|
| 1 | `mobile_app_android_fd` | Modified | Hard | Splash, menu, notification, mipmap/launcher — Stage 04 |
| 2 | `fd_ios` | Modified | Hard | LaunchScreen, menu, notification assets, AppIcon — Stage 04 |
| 3 | Android product flavors / resource dirs | Modified | Hard | Q17 — must not miss regional/flavor copies |
| 4 | iOS schemes / targets | Modified | Hard | Q17 — all agent app targets get consistent assets |

### Non-Code Dependencies
| # | Dependency | Hard/Soft | Owner/Source | Notes |
|---|-----------|-----------|-------------|-------|
| 1 | Official **SVG / export grid** for all densities | Hard | PM / Design | PRD §15 Q1 — pre-implement blocker |
| 2 | **Brand/Design sign-off** on final mipmap/App Icon/splash exports | Hard | Design | FR-08 |
| 3 | Release **branch/tag** for Oct deadline | Soft | Mobile leads | PRD Q4 |
| 4 | Store **submission vs in-app-only** milestone | Soft | PM | PRD Q5 / CPO DoD |
| 5 | Agent comms if store lags git | Soft | PM/GTM | CPO blindspot |

### Cross-Team Dependencies
| # | Team | What They Own | Hard/Soft | Notes |
|---|------|--------------|-----------|-------|
| 1 | Brand / Design | SVG, density grid, sign-off on exports | Hard | Blocks merge |
| 2 | PM | DoD interpretation (store vs exception), scope on tracker | Soft | No Jira edits from agents |
| 3 | Mobile engineering (Android + iOS) | PRs, builds, smoke evidence | Hard | Implementation owners |

## Cross-Epic Discovery
Skipped — epic runs in `.artifact-demo/` local demo mode (no shared artifact repo cross-BU scan).

---

## Working Record

### Session state
- Stage 03 complete; approver recorded above.

### Q&A log
| # | Question | Answer |
|---|----------|--------|
| 1 | Scope covers all PRD flows? | User advanced to next stage (2026-10-07). |

### Decision rationale
- `quick-design` variant: scope derived from `01-prd/prd.md` only.
