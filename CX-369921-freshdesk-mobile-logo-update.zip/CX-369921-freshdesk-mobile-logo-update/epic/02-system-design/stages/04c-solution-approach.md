# Solution Approach: Freshdesk mobile logo update (Android-first)

> Records, per flow/use-case and per cross-cutting design fork, the candidate solution(s), the
> recommended one, and the **finalized** choice the user locks in. Downstream Stage 06 (LLD)
> implements the finalized choices exactly — they do not re-evaluate them.
>
> **Finalized** — user **`go`** (2026-10-07): all recommended options accepted for Android scope.
> iOS flows deferred until `fd_ios` checkout exists.

## Sources & Grounding

| Source | Status |
|--------|--------|
| Scope & flows (`03-scope-and-flows.md`) | Consulted — Android flows F1, F2, F5; iOS F3/F4 deferred |
| PRD (`01-prd/prd.md`) | Consulted — quick-design path (no 01/02 summary stages) |
| Repo manifest (`04-repo-manifest.md`) | Consulted — `mobile_app_android_fd` available; `fd_ios` deferred |
| Context priming (`04b-context-priming.md`) | Consulted — Android asset path map |
| Prism / Git MCP findings | Not available — local clone grounding only (user constraint) |

---

## Solution Approaches by Flow

### F1: Android — cold start shows full logo

**Problem / decision**: How to refresh the **full logo** on splash (and shared login surfaces) without regressing cold start or duplicating assets.

#### Single viable approach

**Approach**: **In-place replacement of `@drawable/ic_full_logo`** — update the existing vector
`freshdesk_app/src/main/res/drawable/ic_full_logo.xml` from brand-approved SVG/path exports (or
replace with a single nodpi PNG/WebP referenced via vector/layer-list if Design requires raster).
`splash`, `login_domain`, and `login_credentials` layouts already bind to this one drawable; no
navigation or Kotlin changes unless contrast/theming requires tint tweaks.

Only viable approach because the codebase already centralizes the full lockup on one resource;
splitting per-screen assets would violate DRY and increase drift risk for the same PRD rule.

#### Decision

- **Status**: Decided
- **Chosen**: Single approach — replace/update `ic_full_logo` centrally
- **Rationale**: Matches 04b inventory; minimal diff; satisfies US-001 splash + login brand moment.
- **Consequences**: LLD lists exact files under `drawable/` and any generated density variants; smoke on cold start + login paths.

---

### F2: Android — menu and notification use logomark only

**Problem / decision**: Notification icons are isolated PNGs; **in-app menu** has no logomark today — where to show logomark-only per PRD.

#### Options

| Factor | Option A: New `ic_logomark` + More/Account toolbar `✅ Recommended` | Option B: Only replace notification + launcher (no in-app logo) |
|--------|---------------------------------------------------------------------|-------------------------------------------------------------------|
| **Description** | Add `drawable/ic_logomark.xml` (and PNGs if needed); insert `ImageView` in `fragment_more_options.xml` toolbar (Account / More tab). Replace all `ic_notification` density PNGs; update adaptive launcher foreground/mipmaps. | Swap notification + launcher assets only; leave More screen text-only. |
| **Pros** | Meets PRD US-001 Scenario 2 (menu = logomark); visible “settings/menu” surface agents use daily. | Smallest layout diff. |
| **Cons** | Small layout + a11y `contentDescription` work. | **Fails PRD** menu acceptance unless “menu” is reinterpreted. |
| **Effort** | S — one layout + drawables | S |
| **Risk** | Low | High — product mismatch |
| **Codebase alignment** | More tab is the agent “account/settings menu” in this app; not the LHS views drawer. | Ignores PRD wording. |
| **Cross-repo impact** | `mobile_app_android_fd` only | Same |

**Recommendation**: Option A — PRD requires logomark in in-app menu; 04b shows no existing menu logo.

#### Decision

- **Status**: Decided
- **Chosen**: Option A — `ic_logomark` on More/Account toolbar + notification/launcher updates
- **Rationale**: User **`go`**; aligns with US-001 and 04b gap analysis.
- **Consequences**: LLD specifies toolbar placement, dimensions, and notification/launcher file list; smoke includes More tab + push icon.

---

### F5: Android — pre-release verification

**Problem / decision**: How to gate quality before store submission.

#### Single viable approach

**Approach**: **Manual smoke checklist** per PRD FR-06 on local `production` flavor build
(emulator + one device): cold start splash, More toolbar logomark, notification small icon,
launcher icon; record results in dev phase artifacts. No new automated test scope for static assets
unless existing screenshot/UI tests fail.

#### Decision

- **Status**: Decided
- **Chosen**: Single approach — manual smoke gate
- **Rationale**: PRD explicit; asset-only epic.
- **Consequences**: LLD references checklist; no CI mandate unless team adds later.

---

### F3 / F4 (iOS) — deferred

Not decided in this stage. Re-run flow blocks when `fd_ios` is primed; mirror Android decisions
(LaunchScreen, AppIcon, notification set, menu surface) with iOS conventions.

---

## Cross-Cutting Design Forks

### D1: Full-logo asset mechanism

**Problem / decision**: Vector path update vs raster drawable for `ic_full_logo`.

| Factor | Option A: Regenerate vector from brand SVG `✅ Recommended` | Option B: Raster PNG/WebP in `drawable-nodpi` |
|--------|--------------------------------------------------------------|--------------------------------------------------|
| **Description** | Design exports SVG → Android vector XML (single `@drawable/ic_full_logo`). | Replace vector with scaled bitmap asset(s). |
| **Pros** | Crisp at all densities; one resource ID unchanged. | Faster if brand only ships PNG. |
| **Cons** | Needs valid SVG→vector conversion (PRD blocker: export grid). | Blur on large splash if densities incomplete. |
| **Effort** | S (with design exports) | S–M |
| **Risk** | Med if SVG complexity high | Med on splash scaling |
| **Codebase alignment** | Current pattern is vector XML. | Requires layout/size validation. |
| **Cross-repo impact** | Android only | Android only |

**Recommendation**: Option A when brand SVG available; fallback to Option B only if Design mandates raster.

#### Decision

- **Status**: Decided
- **Chosen**: Option A primary; Option B fallback if SVG→vector blocked
- **Rationale**: Matches existing `ic_full_logo.xml` pattern; FR-08 sign-off on exports.
- **Consequences**: Block merge until Design delivers SVG/grid (PRD §15 Q1).

---

### D2: Logomark asset set

**Problem / decision**: One logomark source for notification, launcher, and menu.

#### Single viable approach

**Approach**: Derive all logomark surfaces from **`freshdesk-logomark-color-default.png`**
(epic `01-prd/assets/`) plus Design density grid — generate `ic_logomark` vector or PNG,
`ic_notification` mdpi–xxxhdpi, `ic_launcher*` / `ic_launcher_foreground` adaptive set.
`LocationService` small icon stays consistent with logomark policy (`ic_notification` or launcher
per existing code paths).

#### Decision

- **Status**: Decided
- **Chosen**: Single source → multi-density outputs
- **Rationale**: Brand consistency; one sign-off bundle (FR-08).
- **Consequences**: LLD lists every output path; Design sign-off before merge.

---

### D3: Lottie splash assets

**Problem / decision**: Update `assets/splash.json` / `splash_loader.json` or static splash only.

| Factor | Option A: Static splash only (this epic) `✅ Recommended` | Option B: Re-author Lottie with new mark |
|--------|-----------------------------------------------------------|------------------------------------------|
| **Description** | `SplashActivity` + `activity_splash.xml` static `ic_full_logo` is the brand gate; leave Lottie JSON unchanged unless visibly wrong. | Re-export Lottie from motion team. |
| **Pros** | Scope locked to PRD asset swap; Oct deadline. | Pixel-perfect motion brand. |
| **Cons** | Lottie may show old mark if used elsewhere | Out of scope creep; design time |
| **Effort** | S | L |
| **Risk** | Low if Lottie unused on cold start path | Schedule |
| **Codebase alignment** | Cold start uses static layout per 04b. | Only if product requires |

**Recommendation**: Option A unless QA finds old logo in a Lottie-backed screen on cold start.

#### Decision

- **Status**: Decided
- **Chosen**: Option A — static splash/login focus; Lottie out of scope unless QA flags
- **Rationale**: User timeline + asset-only epic.
- **Consequences**: Smoke note: if old mark appears in onboarding Lottie, open follow-up.

---

### D4: About screen branding

**Problem / decision**: `activity_about.xml` uses full `ic_full_logo`.

#### Single viable approach

**Approach**: **Keep full logo on About** — informational screen, not the PRD “menu” surface;
still receives updated `ic_full_logo` via D1. No logomark-only constraint on About.

#### Decision

- **Status**: Decided
- **Chosen**: Keep full logo on About (updated asset)
- **Rationale**: PRD menu rule targets agent menu; About is appropriate for full lockup.
- **Consequences**: None beyond D1 asset swap.

---

## Decision Summary

| # | Flow / Fork | Approaches | Chosen | Recommended? | Status | Owner |
|---|-------------|-----------|--------|--------------|--------|-------|
| F1 | Android cold start / full logo | 1 (single) | Central `ic_full_logo` replace | n/a | Decided | Mobile Android |
| F2 | Android menu + notification | 2 | Option A — More toolbar + icons | Yes | Decided | Mobile Android |
| F5 | Android verification | 1 (single) | Manual smoke | n/a | Decided | Mobile Android / QA |
| F3/F4 | iOS flows | — | Deferred | — | Pending | Mobile iOS |
| D1 | Full-logo mechanism | 2 | Vector primary, raster fallback | Yes | Decided | Design + Android |
| D2 | Logomark outputs | 1 (single) | One source → all densities | n/a | Decided | Design + Android |
| D3 | Lottie | 2 | Static splash scope only | Yes | Decided | Mobile Android |
| D4 | About screen | 1 (single) | Full logo retained | n/a | Decided | Mobile Android |

## Open Items

| # | Flow / Fork | Blocked By | Who Resolves | Notes |
|---|-------------|-----------|--------------|-------|
| 1 | D1 / D2 | Brand SVG + density export grid | PM / Design | PRD §15 Q1 — pre-merge blocker |
| 2 | F3/F4 | `fd_ios` local checkout | Mobile iOS | Mirror Android approach in later 04c/06 pass |
| 3 | D3 | QA finding old logo in Lottie path | QA | Only if smoke fails |
