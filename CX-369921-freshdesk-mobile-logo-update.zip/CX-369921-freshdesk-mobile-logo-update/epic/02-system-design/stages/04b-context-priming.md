# Repo Context Priming: Freshdesk mobile logo update (Android-first)

**Epic:** CX-369921  
**Date:** 2026-10-07  
**Scope:** Android grounding now; **iOS deferred** per PM.

## Repo Context Readiness
| # | Repo | Prism | Git MCP | Notes |
|---|------|-------|---------|-------|
| 1 | `mobile_app_android_fd` | unavailable | n/a (local) | Local clone verified on `main`; grounding via `Read`/`Grep` only. No GitHub/Jira calls. |
| 2 | `fd_ios` | unavailable | n/a | **Deferred** — empty working tree at manifest path; no priming until checkout exists. |

## Repo Guidance
| # | Repo | Bundle (owning BU) | Contents | Design copy (04b-repo-skills) | Checkout install | Notes |
|---|------|---------------------|----------|--------------------------------|-------------------|-------|
| 1 | `mobile_app_android_fd` | none via Prism — **local snapshot** | Checkout already has `.cursor/skills/cxbu-android/` | **written** → `04b-repo-skills/mobile_app_android_fd/cxbu-android-SKILL.md` | **skipped** — user local-only; no `npx`/remote install; checkout skill preserved | Composite CXBU wiring skill; logo work is in `freshdesk_app` module res, not cxbu-android. |
| 2 | `fd_ios` | n/a (deferred) | n/a | n/a | n/a | Re-run row when iOS tree exists. |

## Android branding map (local codebase grounding)

Module: **`freshdesk_app`** (application). No duplicate branding files under `playstoreProduction` / `playstoreStaging` res trees (only `google-services.json` + staging `values.xml`).

| PRD placement | Primary files | Change type |
|---------------|---------------|-------------|
| **Load / splash — full logo** | `src/main/res/layout/activity_splash.xml` → `@drawable/ic_full_logo`; vector `drawable/ic_full_logo.xml` | Replace/update vector paths or swap to layered PNG/WebP exports from brand grid |
| **Login — full logo** (same asset as splash) | `activity_login_domain.xml`, `activity_login_credentials.xml` → `@drawable/ic_full_logo` | Same asset as splash |
| **About — full logo** | `activity_about.xml` → `@drawable/ic_full_logo` | Confirm with PM: keep full lockup or switch to logomark |
| **Notification — logomark** | `NotificationUtil.kt` → `R.drawable.ic_notification`; `MigratorImpl.kt`; `drawable-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/ic_notification.png` | Replace PNG set (+ optional vector if added) |
| **Foreground service / other** | `LocationService.kt` → `R.mipmap.ic_launcher` for small icon | Align with logomark policy |
| **Launcher — logomark** | `mipmap-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/ic_launcher.png`; `mipmap-anydpi-v26/ic_launcher.xml`; `drawable/ic_launcher_foreground.xml`; `values/ic_launcher_background.xml` | Full adaptive-icon set from brand exports |
| **In-app menu — logomark** | **Gap:** `fragment_more_options.xml` (More / Account tab) has **no** logo ImageView — title text only. Bottom nav (`menu_main_navigation.xml`) uses generic tab icons, not Freshdesk mark. LHS drawer is ticket/customer **views**, not brand menu. | **04c decision:** add logomark drawable + layout (likely More toolbar or agreed “menu” surface) or confirm PRD “menu” maps to an existing screen |

**Flavors:** `productFlavors` `production` / `staging` (dimension `server`) — branding lives in `src/main/res`; no extra logo copies in flavor overlays found.

**Splash animation:** `assets/splash.json`, `splash_loader.json` (Lottie) — confirm with design whether logo refresh requires Lottie updates or static splash only (`SplashActivity` uses `activity_splash` layout).

**Entry activity:** `SplashActivity.kt` — launcher / cold start path; no code change expected for asset-only swap.

## iOS
Intentionally **not primed** in this stage. Revisit manifest row + this doc when `fd_ios` working tree is available.

## Resolution
- User constraint: **local repos only** — no Jira, no GitHub API, no remote install/push.
- Prism repo-guidance MCP: **not invoked** (no `list_ai_builder_artifacts` in session); Android design copy taken from existing checkout skill.
- Proceed to **Stage 04c** (solution approach) with **Android-only** LLD scope; iOS rows remain placeholders in manifest.
