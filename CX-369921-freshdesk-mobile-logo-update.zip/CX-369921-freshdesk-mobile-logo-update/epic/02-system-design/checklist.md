# System Design Checklist — CX-369921 Update Mobile Logos

## Cross-team sign-off (from Stage 03 dependencies)
- [ ] Brand / Design — SVG + density export grid and sign-off on final splash/icon exports (FR-08)
- [ ] Mobile engineering (Android) — asset swap + build/smoke for `mobile_app_android_fd`
- [ ] Mobile engineering (iOS) — asset swap + build/smoke for `fd_ios`
- [ ] PM — store submission vs in-app milestone / DoD by 15 Oct 2026 (no AIPDLC Jira edits)

## External readiness gates
- [ ] Design lead — end-to-end mockups N/A (asset swap; brand PNGs in epic)
- [ ] Design lead — accessibility contrast on provided brand assets (smoke)
- [ ] Product Manager — PRD approved (`01-prd/prd.md`, Stage 12 complete)

## Compliance / infra (placeholders — quick-design)
- [ ] Security review — static assets only; no new permissions (confirm at LLD)
- [ ] Infra / platform — N/A (no server changes)

## Stage completion
- [x] 03 — Scope & flows (`02-system-design/stages/03-scope-and-flows.md`)
- [x] 04 — Repo manifest (`02-system-design/stages/04-repo-manifest.md`) — pending user confirm; iOS checkout incomplete
- [x] 04b — Context priming (Android; iOS deferred)
- [x] 04c — Solution approach (`04c-solution-approach.md`, ADRs, HLD redirect)
- [x] 06 — LLD generation (`06-be-lld.md` N/A, `06b-fe-lld.md` Android)
