# System Design Decisions: CX-369921 Update Mobile Logos

**Epic:** CX-369921  
**Date:** 2026-10-07  
**Scope:** Android (`mobile_app_android_fd`); iOS ADRs added when repo is primed.

---

## ADR-001: Central full-logo drawable

| | |
|---|---|
| **Status** | Accepted (Stage 04c — F1, D1) |
| **Context** | Splash, login, and About share `@drawable/ic_full_logo` |
| **Options** | (A) Update vector XML from brand SVG; (B) Raster nodpi PNG/WebP |
| **Decision** | **(A) primary**, (B) fallback if SVG→vector blocked |
| **Consequences** | Single resource ID; all full-logo screens update together |

---

## ADR-002: In-app menu = More/Account toolbar logomark

| | |
|---|---|
| **Status** | Accepted (Stage 04c — F2) |
| **Context** | PRD requires logomark in menu; no logo in current More UI |
| **Options** | (A) New `ic_logomark` in `fragment_more_options` toolbar; (B) Icons only, no menu logo |
| **Decision** | **(A)** |
| **Consequences** | Layout change + a11y label; satisfies US-001 Scenario 2 |

---

## ADR-003: Logomark generation from single brand source

| | |
|---|---|
| **Status** | Accepted (Stage 04c — D2) |
| **Context** | Notification, launcher, and menu need consistent mark |
| **Decision** | Generate `ic_logomark`, `ic_notification` densities, and launcher/adaptive assets from epic logomark PNG + Design grid |
| **Consequences** | FR-08 sign-off on full export set before merge |

---

## ADR-004: Static splash scope; Lottie deferred

| | |
|---|---|
| **Status** | Accepted (Stage 04c — D3) |
| **Context** | `splash.json` Lottie exists; cold start uses static `activity_splash` |
| **Decision** | This epic updates static splash/login assets only; Lottie re-export out of scope unless QA flags regression |
| **Consequences** | Possible follow-up if motion assets show legacy mark |

---

## ADR-005: About screen keeps full logo

| | |
|---|---|
| **Status** | Accepted (Stage 04c — D4) |
| **Decision** | About continues to use `ic_full_logo` (updated), not logomark-only |
| **Rationale** | PRD menu rule does not apply to About informational screen |

---

## ADR-006: Pre-release quality gate

| | |
|---|---|
| **Status** | Accepted (Stage 04c — F5) |
| **Decision** | Manual smoke per PRD FR-06 on local production-flavor build; document results in dev phase |
| **Rationale** | Asset-only change; no new automation mandated in quick-design |
