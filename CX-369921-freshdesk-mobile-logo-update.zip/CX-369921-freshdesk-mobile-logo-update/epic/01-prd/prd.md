# PRD: Freshdesk Mobile App Logo Update

**Epic:** CX-369921  
**Owner:** PM (engineering-led quick epic)  
**BU:** cx  
**Status:** Final (Product Discovery approved 2026-10-07)  
**Date:** 2026-10-07  
**Target Release:** Before **15 Oct 2026**  
**Related Documents:** [CX-369921](https://freshworks.atlassian.net/browse/CX-369921), `01-prd/stages/01-idea-brief.md`, `01-prd/stages/02-requirements.md`, `01-prd/feature-brief.md`, `repos.yaml`

<!-- CPO_FEEDBACK_SLOT -->

> **CPO Review (Stage 12)** — **Verdict: Go** `[Source: CPO Review]`  
> **Major blindspot:** The Oct 15 deadline can be met in git while agents still see old branding until they update from the store — define whether the milestone is **store live**, **submitted**, or an explicit **in-app-only + comms** exception.  
> **Applied:** DoD in §13; brand sign-off + smoke checklist in FR-06; dark-mode note in §8.2; SVG/export grid as pre-implement blocker in §15.

## 1. Overview

Update branding in the **Freshdesk native mobile apps** (Android and iOS) so support agents see the **current Freshdesk logo system** after install or upgrade: **full logo** (mark + wordmark) on the **loading screen**, **logomark only** in the **in-app menu** and **notifications**, and an updated **launcher/app icon**. Work is limited to the `mobile_app_android_fd` and `fd_ios` codebases; validate via **local clone, build, and manual smoke** before store submission. Store listing creative updates are deferred.

## 2. Problem Statement

Agents who use the Freshdesk mobile apps still encounter **legacy Freshdesk logo assets** on cold start, in navigation, on the home screen icon, and in notification affordances. That mismatch with current brand guidelines reduces trust and looks inconsistent with the refreshed Freshdesk identity.

- **Who is affected:** **Support agents** using the Freshdesk Android and iOS apps (primary persona only).
- **How they solve it today:** They use apps that ship old bundled assets; there is no agent-side workaround.
- **Impact of the problem:** Brand inconsistency on a high-visibility surface (home screen + first launch); risk of confusion during the company logo refresh. `[Source: CX-369921]` — *No VoC/Baikal quantification in this quick-prd path.*

## 3. Goals, Non-Goals & Out of Scope

**Goals**

- Ship updated logo assets on **Android and iOS** before **15 Oct 2026**.
- Enforce placement rules: **load = full logo**; **menu + notifications + launcher = logomark only**.
- **Zero functional regressions** attributable to the asset swap within 20 days–1 month post-release (primary success measure).
- Validate through **local builds** and manual smoke on each platform before production/store push. `[Source: CPO Review]`
- **Definition of done (deadline):** By **15 Oct 2026**, both platforms are **store-submitted or live** with new in-app assets, **or** PM documents an approved exception (in-app milestone only + agent comms plan). `[Source: CPO Review]`

**Non-Goals**

- Changing ticket workflows, Freddy/AI surfaces, or agent productivity features.
- Updating **Jira epic** fields from this pipeline (PM owns tracker).
- Dark-mode or alternate logo variants (single default treatment only).

**Out of Scope (this iteration)**

- Web agent UI, help center, email templates, **Freshdesk Omni**, and product-wide logo sweeps outside the two mobile repos.
- **Play Store / App Store** marketing screenshots and feature graphics (in-app assets first; upload later).
- White-label / custom tenant branding (none for Freshdesk mobile).

## 4. Users, Personas & Use Cases

### Support agent (mobile)

- **Persona:** Freshdesk support agent — uses mobile app for ticket handling on the go.
- **Goals:** Open a trusted, on-brand app quickly after update.
- **Pain points:** Outdated icon and splash undermine confidence in “current” Freshdesk.
- **Key use cases:**
  1. Install or update app → see **new launcher icon** and **full logo** on load.
  2. Open menu → see **logomark only**.
  3. Receive push → notification icon shows **logomark only**.
- **Assumptions:** Agent has a supported Freshdesk mobile build; no custom white-label build.

## 5. Solution & Approach

**Approach**

1. **Source assets** from epic folder (PM-provided references; engineering may generate density variants):
   - Full logo (load): `01-prd/assets/freshdesk-logo-full-default.png` (738×128 PNG).
   - Logomark (menu, notifications, launcher): `01-prd/assets/freshdesk-logomark-color-default.png` (128×128 PNG).
2. **Android** (`mobile_app_android_fd`): Replace splash/loading, menu, notification, and mipmap/launcher resources per repo conventions; build and smoke on emulator/device.
3. **iOS** (`fd_ios`): Replace launch screen/storyboard assets, in-app menu asset, notification icon set, and `AppIcon` per repo conventions; build and smoke on simulator/device (**cold start** validation).
4. **Release path:** Local verification first; **store uploads later** per PM unless DoD requires submission by Oct 15. **Brand/Design sign-off** on final density exports before merge. `[Source: CPO Review]` No Jira epic edits from AIPDLC.

**Mini business case:** Qualitative — brand alignment on mobile agent channel; no adoption/revenue model in quick-prd. `[Source: Stage 01–02 intake]`

## 7. User Stories / Features

### US-001: Android — updated Freshdesk mobile branding

**As a** support agent on Android,  
**I want** the Freshdesk app to show the new logo on launch, menu, notifications, and home screen,  
**So that** I see consistent Freshdesk branding after I update the app.

**Priority:** P0  
**FR Link:** CX-369921  
**Figma:** N/A — assets in `01-prd/assets/`

**Acceptance Criteria**

**1. Positive Scenarios:**
* Scenario 1: **Given** a build with updated assets, **When** I cold-start the app, **Then** the loading/splash screen shows the **full logo** (mark + “Freshdesk”).
* Scenario 2: **Given** the app is open, **When** I open the in-app menu, **Then** I see the **logomark only** (no wordmark lockup).
* Scenario 3: **Given** a notification is shown, **When** I view the status bar/shade, **Then** the notification uses the **logomark** small icon treatment.
* Scenario 4: **Given** the app is installed, **When** I view the home screen, **Then** the launcher icon shows the **logomark**.

**2. Negative & Error Scenarios:**
* Scenario 1: **Given** asset files are missing or corrupt, **When** the app is built, **Then** the build fails or QA blocks release (no shipped build with blank splash).
* Scenario 2: **Given** an old build is installed, **When** I update to the new build, **Then** I do not see a crash loop on launch.

**3. Edge Case Scenarios:**
* Scenario 1: **Given** low-memory kill after splash, **When** I resume the app, **Then** branding still renders correctly (no stale hybrid old/new assets on same screen).
* Scenario 2: **Given** no white-label flavors, **When** I install the standard Freshdesk app, **Then** all standard variants receive the same logo set (confirm no orphaned flavor dirs in repo discovery).

**4. Impact with Other Systems:**
* Scenario 1: **Given** push notification pipeline unchanged, **When** logos update, **Then** notification delivery and payload behavior are unchanged (visual icon only).

**5. Non-Functional Requirements:**
* **Performance/Scalability:** Splash and icon assets must not measurably regress cold-start time vs baseline on a mid-range device (smoke observation).
* **Security:** Asset swap only; no new permissions or network behavior.
* **Reliability:** No increase in crash rate on launch attributable to logo change (20d–1mo observation goal).

**UX Experience Aspects:**
* **Usability:** Full logo only where users expect “brand moment” (load); icon-only elsewhere to avoid clutter.
* **Accessibility:** Logo images must retain sufficient contrast (brand-provided assets assumed compliant).
* **Responsiveness:** Splash scales correctly across common Android densities (repo mipmap sets complete).

---

### US-002: iOS — updated Freshdesk mobile branding

**As a** support agent on iOS,  
**I want** the Freshdesk app to show the new logo on launch, menu, notifications, and home screen,  
**So that** I see consistent Freshdesk branding after I update the app.

**Priority:** P0  
**FR Link:** CX-369921  
**Figma:** N/A — assets in `01-prd/assets/`

**Acceptance Criteria**

**1. Positive Scenarios:**
* Scenario 1: **Given** a build with updated assets, **When** I **cold start** the app (not in app switcher), **Then** the launch/loading experience shows the **full logo**.
* Scenario 2: **Given** the app is open, **When** I open the in-app menu, **Then** I see the **logomark only**.
* Scenario 3: **Given** a push notification is displayed, **When** I view it, **Then** branding uses the **logomark** (not the full wordmark lockup).
* Scenario 4: **Given** the app is installed, **When** I view the home screen, **Then** the **App Icon** is the updated logomark.

**2. Negative & Error Scenarios:**
* Scenario 1: **Given** incomplete App Icon set, **When** archiving for TestFlight/App Store, **Then** validation errors are resolved before ship.
* Scenario 2: **Given** launch storyboard misconfigured, **When** cold starting, **Then** app does not hang on blank launch screen.

**3. Edge Case Scenarios:**
* Scenario 1: **Given** iOS caches launcher icon, **When** upgrading from old build, **Then** reinstall or documented cache refresh shows new icon (QA notes if iOS delay expected).
* Scenario 2: **Given** multiple schemes/targets in repo (TBD in system design), **When** assets are updated, **Then** all Freshdesk agent app targets receive consistent assets unless discovery proves an exception.

**4. Impact with Other Systems:**
* Scenario 1: **Given** APNs unchanged, **When** icons update, **Then** notification registration and delivery behave as before.

**5. Non-Functional Requirements:**
* **Performance/Scalability:** Cold start remains acceptable (smoke on simulator + one device).
* **Security:** Asset-only change.
* **Reliability:** No launch crashes tied to asset bundle (20d–1mo goal).

**UX Experience Aspects:**
* **Usability:** Same placement rules as Android for cognitive consistency cross-platform.
* **Accessibility:** VoiceOver labels on menu branding unchanged in meaning (still “Freshdesk”).
* **Responsiveness:** Launch screen and icons render correctly on common iPhone sizes used by agents.

## 8. Requirements

### 8.1 Functional

| ID | Requirement |
|----|-------------|
| FR-01 | Replace **loading/splash** assets with **full logo** (`freshdesk-logo-full-default.png` or design-approved exports). |
| FR-02 | Replace **in-app menu** logo with **logomark only** (`freshdesk-logomark-color-default.png` or exports). |
| FR-03 | Replace **notification** icon/branding with **logomark only**. |
| FR-04 | Replace **launcher / App Icon** with **logomark** per platform guidelines. |
| FR-05 | Implement FR-01–FR-04 in **`mobile_app_android_fd`** and **`fd_ios`**. |
| FR-06 | Use **local clone + build + manual smoke** as the pre-release quality gate; complete the **smoke checklist** (cold start/load, menu, notification icon, launcher × Android × iOS) and attach results in dev phase. `[Source: CPO Review]` |
| FR-08 | Obtain **Brand/Design sign-off** on generated mipmap/App Icon/splash exports before merge to main/release branch. `[Source: CPO Review]` |
| FR-07 | Do **not** modify CX-369921 in Jira from AIPDLC automation or agents. |

### 8.2 Non-Functional

| Area | Requirement |
|------|-------------|
| **Performance** | No material regression in cold-start time (smoke comparison). |
| **Security / privacy** | No new data collection; static assets only. |
| **Reliability** | No new crashes on launch/load/menu/notification paths attributable to logo swap. |
| **Accessibility** | Use brand assets as provided; no text baked into inaccessible images where system text is required. |
| **Compliance** | N/A beyond standard app store asset rules. |
| **Mobile** | Primary surface — Android mipmaps + adaptive icon rules; iOS App Icon + LaunchScreen. |
| **APIs** | No API changes. |
| **Billing / entitlements** | N/A. |
| **Fair usage** | N/A (static assets). |
| **Dark mode / appearance** | Single light-brand assets in scope; if app shell uses dark backgrounds, verify contrast in smoke or defer dark-variant to follow-up (no alternate art in this epic). `[Source: CPO Review]` |

## 13. Rollout & Launch Plan

### 13.1 Phases

| Phase | Activity |
|-------|----------|
| **1 — Dev** | Clone repos to local workspace (`repos.yaml` paths); swap assets; PRs to each repo. |
| **2 — Verify** | Manual smoke: Android emulator/device + iOS simulator/device (cold start, menu, notification icon, launcher). |
| **3 — Release** | Merge and ship mobile releases per team cadence; meet **§3 Definition of done** by **15 Oct 2026** (store live/submitted or PM exception). |
| **4 — Store (deferred)** | Play/App Store listing graphics upload when PM ready — not blocking in-app asset epic. |

### 13.2 Availability

Standard Freshdesk mobile apps for agents (no white-label).

### 13.3 GTM

Minimal — visual brand refresh; no new feature announcement required unless PM/GTM chooses.

## 14. Risks & Mitigations

| Risk | Mitigation |
|------|------------|
| Wrong asset in wrong slot (full logo in notification) | PM placement rules in FR-01–03; smoke checklist per platform. |
| Incomplete density/icon sets → build failure or blurry icons | Generate full mipmap/App Icon sets from brand PNG/SVG; CI/archive validation. |
| Regional/flavor duplicate asset dirs missed (Q17) | **System-design Stage 04** repo manifest scan for product flavors/schemes. |
| Launcher icon cache shows old icon after upgrade | Document reinstall step in QA; accept platform caching behavior. |
| Timeline before 15 Oct 2026 | Parallel Android/iOS PRs; scope locked to assets only. |
| PNG-only intake vs vector production needs | PM may supply export pack; open question if blur on large splash. |

## 15. Open Questions

| # | Question | Owner | Next step |
|---|----------|-------|-----------|
| 1 | Official **SVG / export grid** from brand for all densities? | PM / Design | **Pre-implement blocker** — required before asset swap PRs merge |
| 2 | Exact **file paths** in each repo for splash, menu, notification | Engineering | Repo discovery + first PR |
| 3 | **Android/iOS flavor/scheme** duplication for regional builds? | Engineering | Inspect cloned repos (Stage 04) |
| 4 | Which **release branch/tag** to target for Oct deadline? | Mobile leads | Confirm in plan/implement |
| 5 | **Store submission** date vs in-app-only milestone | PM | After local smoke green |
