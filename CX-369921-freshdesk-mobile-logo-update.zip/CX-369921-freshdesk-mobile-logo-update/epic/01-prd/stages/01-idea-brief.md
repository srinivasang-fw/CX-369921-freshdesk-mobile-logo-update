# Idea Brief: Freshdesk Mobile App Logo Update

## Feature Summary

Replace legacy Freshdesk branding in the **native Freshdesk mobile apps** (Android and iOS) with the current **Freshdesk logomark** (green circle, white flower/sunburst — default color mode). The change is asset-driven: update launcher icons, in-app brand marks, and any bundled logo resources so customers see consistent Freshworks/Freshdesk identity on mobile.

[Source: Jira CX-369921] Epic summary: "Update Freshdesk logo"; description mentions logo updates "throughout the product" for Freshdesk and Freshdesk Omni. **Engineering intake for this AIPDLC run narrows scope to mobile native apps only** — see Initial Scope.

## Target Users

| Persona | Need |
|---------|------|
| **Freshdesk mobile agents** | Recognizable, up-to-date app icon and in-app branding on home screen and within the app |
| **IT / admin teams** | Store listings and installed apps reflect current brand (no outdated logo on devices) |
| **Freshworks brand/design** | Single approved logomark applied consistently on mobile surfaces |

## Business Context

**Why now:** Epic is **High** priority, status **Engineering In Progress**, labels `H22026` and `ai-accelerated-plan` [Source: Jira CX-369921]. Brand refresh requires mobile parity with the approved logomark.

**Expected impact:** Consistent brand presentation on mobile; reduced confusion from outdated icons; alignment with company visual identity on the two primary mobile codebases.

**Repos in scope (intake):**

- Android: https://github.com/freshdesk/mobile_app_android_fd  
- iOS: https://github.com/freshdesk/fd_ios  

**Target asset:** `01-prd/assets/freshdesk-logomark-color-default.png` (intake reference; design may supply SVG / full density export set before implementation).

## Initial Scope

### In Scope

- Freshdesk **Android** app (`mobile_app_android_fd`) — app icon / launcher and in-app logo assets tied to Freshdesk branding
- Freshdesk **iOS** app (`fd_ios`) — same class of assets
- Derive platform-required size variants from the approved logomark (mipmap, App Icon set, etc.) per repo conventions
- Visual QA on devices/simulators for icon and primary in-app logo placements

### Out of Scope (this run)

- Web product, helpkit, or desktop surfaces (unless explicitly added later)
- **Freshdesk Omni** and non-mobile products mentioned in Jira epic description (unless PM expands scope)
- Broader "throughout the product" logo sweep beyond the two mobile repos above
- Functional feature changes unrelated to branding assets

## Known Constraints

- **Jira epic (CX-369921):** Do **not** update the epic in Jira from this pipeline — PM owns tracker edits separately.
- Two separate repos and release trains (Android vs iOS) — likely coordinated but independent PRs/builds
- App store / Play Store icon updates may require store submission cadence separate from in-app assets
- Intake PNG is 128×128; production may require official **SVG** or brand export pack from design
- Must not break white-label or flavor-specific branding if present in mobile repos (to be confirmed in Stage 02)

## Search Keywords

Freshdesk mobile, app icon, launcher icon, logomark, brand refresh, mobile_app_android_fd, fd_ios, Android mipmap, iOS AppIcon, CX-369921, logo asset replacement, Freshdesk Omni (out of scope unless expanded)

## Open Questions

- Exact list of **in-app** surfaces beyond launcher (splash, login, nav header, about screen)?
- Are **Freshdesk Omni** mobile apps in these repos or separate codebases?
- Official **SVG + export grid** from brand/design vs intake PNG only?
- Minimum OS / app versions and **store listing** screenshot updates required?
- Any **dark mode** or alternate logomark variants needed on mobile?

---

## Working Record

### Session state

- **Stage:** 01 — Idea Intake  
- **Status:** complete (user approved `y`, recorded)  
- **Mode:** interactive (BLOCKING)  
- **Connectors:** Jira MCP — CX-369921 fetched  

### Q&A log

| Turn | Question / input | Answer / action |
|------|------------------|-----------------|
| 1 | `/fw-ideate-prd` + workflow approval | Approved quick-epic / quick-prd (4 stages) |
| 2 | Prior intake: mobile-only, repos, logomark asset | Reflected in brief; Jira text broader than mobile |
| 3 | Do not update the Epic in Jira | Recorded — PM will update Jira; AIPDLC must not modify CX-369921 |
| 4 | "Let's start stage 1" | Re-opened walkthrough; brief on disk — awaiting **`y`** to record |
| 5 | `y` | Stage 01 recorded; advance to Stage 02 |

### Decision rationale

- Scoped to **mobile native apps** per explicit user intake; Jira epic text kept as context with documented narrowing.  
- Repos and reference asset paths taken from `01-prd/feature-brief.md` on disk.
- No Jira writeback for epic description/summary — out of scope for agents and implementers on this run.
