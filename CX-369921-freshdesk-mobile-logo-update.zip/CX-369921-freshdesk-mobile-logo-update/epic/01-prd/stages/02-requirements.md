# Requirements: Freshdesk Mobile Logo Update

## Confirmed Problem

Support agents using the **Freshdesk native mobile apps** (Android and iOS) still see **legacy Freshdesk branding** on the **loading screen**, **in-app menu**, **launcher/home-screen icon**, and **notifications**. The product must show the **current approved Freshdesk logo system** without functional regressions.

**Primary users:** Support agents only.  
**Deadline:** Live **before 15 Oct 2025**.  
**Jira:** [CX-369921](https://freshworks.atlassian.net/browse/CX-369921) — read-only for this pipeline; PM owns tracker edits.

## User Workflows

1. **Install / update app** → Agent sees **new launcher icon** and, on open, **loading screen with full logo** (mark + “Freshdesk” name).
2. **Daily use** → In-app **menu** shows **logomark only** (no wordmark).
3. **Notifications** → Notification affordances use **logomark only**, consistent with menu treatment.

## Requirements

### Functional

- Replace **loading / splash** artwork with the **full logo** asset (`01-prd/assets/freshdesk-logo-full-default.png`).
- Replace **menu** logo with **logomark only** (`01-prd/assets/freshdesk-logomark-color-default.png`).
- Replace **notification** logo/icon treatment with **logomark only** (same mark asset family).
- Update **launcher / app icon** to the approved **logomark** (platform-appropriate sizes).
- Apply changes in **both** repos: `mobile_app_android_fd` (Android), `fd_ios` (iOS).
- **No white-label** variants — all standard Freshdesk mobile builds in scope.
- **Single logo treatment** — no dark-mode or alternate brand variants in this epic.

### Non-Functional

- **Regression bar:** Within **20 days–1 month** of release, **no production incidents** attributable to the logo/asset swap (crashes, failed launch, broken notifications, broken load screen).
- **Visibility:** After update, agents can clearly see **new branding** on load and in menu/notifications/icon.
- **Store listings:** **Out of scope** for this epic — in-app assets only first (no Play/App Store marketing graphic updates required here).
- **Asset fidelity:** Use PM-provided PNG references; engineering generates platform density sets unless PM supplies a full export pack later.

## Goals

- Ship updated logos on **Android and iOS** before **15 Oct 2025**.
- **Full logo** on load; **icon only** in menu and notifications; updated **launcher icon**.
- Zero functional breakage from the change (primary success measure).

## Non-Goals

- Web agent UI, help center, email templates, **Freshdesk Omni**, or product-wide logo sweeps outside the two mobile repos.
- Freddy / AI co-pilot branding (no known scope).
- Channel-specific ticket UI branding differences.
- Cross-product (Freshservice, Freshchat, etc.) integration screens.
- Jira epic field updates from AIPDLC.
- App Store / Play Store screenshot or feature-graphic refresh.

## Success Criteria

| Criterion | Measure |
|-----------|---------|
| **On time** | Production or agreed release channel live **before 15 Oct 2025** |
| **Correct placement** | Load = full logo; menu + notifications = logomark only; launcher = logomark |
| **Stability** | No new crashes or broken flows tied to asset changes (smoke: cold start, login/load, open menu, receive/display notification) |
| **Visibility** | Post-update builds visibly show new logo on the surfaces above |

**QA / delivery approach (PM):** **Clone both mobile repos locally**, swap logo assets, **build and verify on device/simulator** before any store submission. **Play/App Store uploads can happen later** — this epic targets in-app assets and local validation first (aligns with in-app-only store graphic scope).

## CX-Specific Constraints

| Topic | Resolution |
|-------|------------|
| Freshdesk module | Mobile **shell / branding** only — not Tickets workflow logic |
| Persona | **Agents** only |
| Freddy / AI | **N/A** |
| Channel | **N/A** (same UI regardless of ticket channel) |
| Multi-pod / residency / regional builds | **TBD** — repo discovery (system-design Stage 04) must confirm whether Android product flavors or iOS schemes duplicate assets per region/pod; GitHub was not readable from this session (private repos). Assume **same assets all regions** until proven otherwise in repo manifest. |
| Integrations | **N/A** |

## Clarifying Q&A

| ID | Question | Answer |
|----|----------|--------|
| Q1 | In-app surfaces | Loading screen (**full logo**); menu + notifications (**icon only**); launcher icon |
| Q2 | Out of scope | Confirmed: web, help, email, Omni as discussed |
| Q3 | White-label | None; all mobile app builds included |
| Q4 | Persona | Support agents only |
| Q5 | Emphasis | New logo visible after update |
| Q6 | Date | Before **15 Oct 2025** |
| Q7 | Success | Nothing breaks; 20d–1mo stability |
| Q8 | Exports | PM can supply pack; PNG references on disk for now |
| Q9 | OS min | N/A |
| Q10 | Store graphics | In-app only first |
| Q11 | Variants | Single logo only |
| Q12 | Notifications | Include Freshdesk logomark |
| Q13 | QA sign-off | Local **clone + build + smoke** on Android & iOS; store upload deferred |
| — | Local repos | Target path: `/Users/sgovindarajan/Documents/freshdesk-mobile-repos/` (clone in progress) |
| Q14–Q16, Q18 | CX module / Freddy / channel / integrations | N/A |
| Q17 | Regional/pod builds | **Check repos** in Stage 04; not verified in Stage 02 |

**Asset update (2025-10-07):** Full logo added as `01-prd/assets/freshdesk-logo-full-default.png`; logomark remains `freshdesk-logomark-color-default.png`.

---

## Working Record

### Session state

- **Stage:** 02 — Clarify Requirements  
- **Status:** complete (user: proceed to next step)  
- **Mode:** interactive (BLOCKING)  
- **next_action:** PM replies **`y`** to approve requirements (or lists edits); confirm/adjust Q13 QA line  

### Q&A log (continued)

| Turn | Input | Action |
|------|-------|--------|
| 6 | Clone repos, build locally; upload to stores later | Recorded in QA approach; `repos.yaml` paths → `~/Documents/freshdesk-mobile-repos/`; SSH clone started |

### Decision rationale

- Logo placement split (full vs icon-only) is explicit PM rule for load vs menu/notifications.  
- Q17 deferred to repo discovery — inspect cloned trees for flavors/schemes once clone completes.
