# Feature brief (raw intake)

**Captured at:** 2026-10-07 (from `/fw-init` and follow-up scope clarification)

## Scope

Update the **Freshdesk Mobile app logo** on **native mobile apps only** (not web/desktop product surfaces unless explicitly pulled in later).

## Repositories (user-provided)

| Platform | GitHub |
|----------|--------|
| Android | https://github.com/freshdesk/mobile_app_android_fd |
| iOS | https://github.com/freshdesk/fd_ios |

Local clone paths and branches to be confirmed at repo discovery (system-design Stage 04).

## Target logo (replacement assets)

| Use case | Asset | Path |
|----------|--------|------|
| **App load / splash (full logo)** | Logomark + “Freshdesk” wordmark | `01-prd/assets/freshdesk-logo-full-default.png` (738×128 PNG) |
| **Menu, notifications, launcher icon** | **Icon / logomark only** (no wordmark) | `01-prd/assets/freshdesk-logomark-color-default.png` (128×128 PNG) |

**Placement rules (PM):**

1. **Loading screen** — show the **full logo** (mark + name).  
2. **In-app menu** and **push notification** branding — **logomark only**.

Platform density exports (mipmap, App Icon, notification small icon) to be derived in implementation; PM may supply additional export packs on request.

Replace existing assets in **both** Android and iOS repos per the table above.

## Tracker

**Jira epic:** [CX-369921](https://freshworks.atlassian.net/browse/CX-369921) — tracker summary: "Update Freshdesk logo" (mobile-specific scope above supersedes generic wording for this pipeline). **Do not edit the epic in Jira from AIPDLC** — PM owns tracker updates.

## Raw intake (verbatim)

- `/fw-init`: Update Mobile logos
- Follow-up: This is specifically for the mobile apps. We have to update the Freshdesk Mobile app logo. Android + iOS repos linked above.
- Follow-up: Attached logomark (default color) is the logo that should replace current mobile app logos.
