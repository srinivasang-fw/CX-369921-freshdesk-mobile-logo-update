# Fresh chat handoff — CX-369921 Update Mobile Logos

**Copy this file into a new Cursor chat** (attach with `@` or paste). Then run: **`/fw-system-design`**

---

## Epic identity

| Field | Value |
|-------|--------|
| Epic | **CX-369921** |
| Slug | `update-mobile-logos` |
| BU | **cx** |
| Workflow | **quick-epic** (product-discovery **done** → next: **system-design** `quick-design`) |
| Jira | https://freshworks.atlassian.net/browse/CX-369921 (**read-only** — do not edit epic from AIPDLC) |

## Workspace paths

| What | Path |
|------|------|
| Artifact repo (workspace) | `/Users/sgovindarajan/Documents/ai-pdlc-artifacts` |
| Epic root | `/Users/sgovindarajan/Documents/ai-pdlc-artifacts/.artifact-demo/cx/active/CX-369921-update-mobile-logos` |
| Workspace pointer | `/Users/sgovindarajan/Documents/ai-pdlc-artifacts/.aipdlc/workspace.json` |
| Final PRD | `…/01-prd/prd.md` |
| Phase checklist | `…/01-prd/stages/12-final-checklist.md` |

## What we’re building (one paragraph)

Replace legacy Freshdesk branding in **native mobile apps only** (Android + iOS) for **support agents**. **Loading screen** = **full logo** (mark + wordmark). **Menu, notifications, launcher** = **logomark only**. Clone locally, swap assets, build, manual smoke; store listing art deferred; target **before 15 Oct 2026** (DoD: store submitted/live or PM exception documented).

## Repos

| Platform | GitHub | Local path (intended) |
|----------|--------|------------------------|
| Android | https://github.com/freshdesk/mobile_app_android_fd | `/Users/sgovindarajan/Documents/freshdesk-mobile-repos/mobile_app_android_fd` |
| iOS | https://github.com/freshdesk/fd_ios | `/Users/sgovindarajan/Documents/freshdesk-mobile-repos/fd_ios` |

See `repos.yaml` in epic root. Clone via SSH if HTTPS fails.

## Logo assets (in epic)

| Use | File |
|-----|------|
| Load / splash | `01-prd/assets/freshdesk-logo-full-default.png` (738×128) |
| Menu, notifications, app icon | `01-prd/assets/freshdesk-logomark-color-default.png` (128×128) |

**Open blocker:** Brand SVG / full density export grid before implement PRs merge (PRD §15 Q1).

## Product Discovery — completed stages

- [x] 01 Idea intake → `01-prd/stages/01-idea-brief.md`
- [x] 02 Clarify requirements → `01-prd/stages/02-requirements.md`
- [x] 11 Draft PRD → `01-prd/prd.md` (**approved**)
- [x] 12 Finalize → `01-prd/stages/12-final-checklist.md`

## User stories (PRD §7)

- **US-001** — Android branding (full AC in PRD)
- **US-002** — iOS branding (cold start, etc.)

## Manual smoke (after asset swap)

Per platform: cold start → **full logo** on load; **menu** = icon only; **notification** icon = logomark; **launcher** = logomark; no launch crash.

## Out of scope

Web, Omni product sweep, email/helpkit, Freddy UI, Jira epic edits, store marketing screenshots (in-app first).

## Next command

```
/fw-system-design
```

System design should: confirm repo clone state, map asset file paths in both codebases, check Android flavors / iOS schemes (Q17), produce quick-design artifacts under `02-system-design/`.

## Optional starter prompt for new chat

```
Epic CX-369921 mobile logo update — Product Discovery is complete.
Read @FRESH-CHAT-HANDOFF.md and @01-prd/prd.md, then run /fw-system-design.
```
