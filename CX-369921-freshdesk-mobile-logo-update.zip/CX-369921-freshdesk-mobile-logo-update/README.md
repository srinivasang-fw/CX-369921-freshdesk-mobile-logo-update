# CX-369921 — Freshdesk mobile logo update (pack)

Epic **CX-369921** — Product Discovery, system design, brand assets, and **Android implementation overlay** for `freshdesk/mobile_app_android_fd`.

This repo is a **portable pack** for handoff and PR preparation. It is not a fork of the full Freshdesk Android monorepo.

## Contents

| Path | Description |
|------|-------------|
| [`epic/`](epic/) | PRD, system design (LLD), `repos.yaml`, handoff |
| [`brand-assets/`](brand-assets/) | Full logo (738×128) and logomark (128×128) PNGs |
| [`android-implementation/`](android-implementation/) | Changed/added files under `mobile_app_android_fd/` + unified patch |

## Apply Android changes

1. Clone upstream: `git clone git@github.com:freshdesk/mobile_app_android_fd.git`
2. Copy files from `android-implementation/mobile_app_android_fd/` into the clone (preserve paths), **or** apply:
   ```bash
   git apply --directory=mobile_app_android_fd android-implementation/mobile_app_android_fd-logo.patch
   ```
3. Delete the file listed in `android-implementation/DELETED_FILES.txt` if not removed by patch:
   - `freshdesk_app/src/main/res/drawable/ic_full_logo.xml`
4. Build (JDK 17 + Android SDK):
   ```bash
   export JAVA_HOME="/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home"
   ./gradlew :freshdesk_app:assemblePlaystoreProductionDebug
   ```
5. Manual smoke: splash (full logo), More/Account toolbar (logomark), notification icon, launcher.

## Upstream reference

- Android: https://github.com/freshdesk/mobile_app_android_fd  
- iOS (not implemented in this pack): https://github.com/freshdesk/fd_ios  
- Jira (read-only): https://freshworks.atlassian.net/browse/CX-369921  

## Status

- **Android:** implementation files included; iOS deferred.  
- **Design:** PNGs included; formal SVG/density sign-off per PRD FR-08 before production merge.
